/*############################################################################*/
/*#                                                                          #*/
/*#  MIT HRTF C Library                                                      #*/
/*#  Copyright � 2007 Aristotel Digenis                                      #*/
/*#                                                                          #*/
/*#  Filename:  mit_hrtf_filter.h                                            #*/
/*#  Version:   0.1                                                          #*/
/*#  Date:      04/05/2007                                                   #*/
/*#  Author(s): Aristotel Digenis                                            #*/
/*#  Credit:    Bill Gardner and Keith Martin                                #*/
/*#  Licence:   MIT                                                          #*/
/*#                                                                          #*/
/*############################################################################*/


#ifndef _MIT_HRTF_FILTER_H
#define _MIT_HRTF_FILTER_H

#define MIT_HRTF_AZI_POSITIONS_00	37
#define MIT_HRTF_AZI_POSITIONS_10	37
#define MIT_HRTF_AZI_POSITIONS_20	37
#define MIT_HRTF_AZI_POSITIONS_30	31
#define MIT_HRTF_AZI_POSITIONS_40	29
#define MIT_HRTF_AZI_POSITIONS_50	23
#define MIT_HRTF_AZI_POSITIONS_60	19
#define MIT_HRTF_AZI_POSITIONS_70	13
#define MIT_HRTF_AZI_POSITIONS_80	7
#define MIT_HRTF_AZI_POSITIONS_90	1

#define MIT_HRTF_44_TAPS	128


typedef struct mit_hrtf_filter_44_str
{
	short left[MIT_HRTF_44_TAPS];
	short right[MIT_HRTF_44_TAPS];
}mit_hrtf_filter_44;


typedef struct mit_hrtf_filter_set_44_str
{
	mit_hrtf_filter_44 e_10[MIT_HRTF_AZI_POSITIONS_10];
	mit_hrtf_filter_44 e_20[MIT_HRTF_AZI_POSITIONS_20];
	mit_hrtf_filter_44 e_30[MIT_HRTF_AZI_POSITIONS_30];
	mit_hrtf_filter_44 e_40[MIT_HRTF_AZI_POSITIONS_40];
	mit_hrtf_filter_44 e00[MIT_HRTF_AZI_POSITIONS_00];
	mit_hrtf_filter_44 e10[MIT_HRTF_AZI_POSITIONS_10];
	mit_hrtf_filter_44 e20[MIT_HRTF_AZI_POSITIONS_20];
	mit_hrtf_filter_44 e30[MIT_HRTF_AZI_POSITIONS_30];
	mit_hrtf_filter_44 e40[MIT_HRTF_AZI_POSITIONS_40];
	mit_hrtf_filter_44 e50[MIT_HRTF_AZI_POSITIONS_50];
	mit_hrtf_filter_44 e60[MIT_HRTF_AZI_POSITIONS_60];
	mit_hrtf_filter_44 e70[MIT_HRTF_AZI_POSITIONS_70];
	mit_hrtf_filter_44 e80[MIT_HRTF_AZI_POSITIONS_80];
	mit_hrtf_filter_44 e90[MIT_HRTF_AZI_POSITIONS_90];
}mit_hrtf_filter_set_44;

#endif // _MIT_HRTF_FILTER_H
