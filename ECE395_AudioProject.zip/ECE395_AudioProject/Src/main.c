/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include <arm_common_tables.h>
#include "C:\Users\kylep2\STM32CubeIDE\workspace_1.0.2\ECE395_AudioProject\Inc\arm_math.h"
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "MY_CS43L22.h"
#include <math.h>
#include <stdio.h>
#include <arm_const_structs.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define FS 44100.0f
#define F_OUT 440.0f
#define FLOAT_BUF_SIZE 128
#define NUM_TAPS 128
#define LEFT 0
#define RIGHT 1
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

I2S_HandleTypeDef hi2s3;
DMA_HandleTypeDef hdma_spi3_tx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2S3_Init(void);
/* USER CODE BEGIN PFP */
void get_sin(float32_t *sin_buffer);
void filter();
void fill_DMA_buffer();
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//float SinVal;
float sample_dt = FS / F_OUT;
float coeffs[2][128] = {{3.05175781e-05, 3.05175781e-05, 6.10351562e-05, 6.10351562e-05,
		   3.05175781e-05, 0.00000000e+00, 3.05175781e-05,-3.05175781e-05,
		   0.00000000e+00, 3.05175781e-05, 3.05175781e-05, 0.00000000e+00,
		   6.10351562e-05, 1.22070312e-04,-6.10351562e-05, 0.00000000e+00,
		   9.15527344e-05,-3.05175781e-05, 1.83105469e-04, 1.52587891e-04,
		   2.44140625e-04, 3.66210938e-04, 2.13623047e-04,-1.52587891e-04,
		   1.53808594e-02, 4.51049805e-02, 1.83105469e-02,-2.53295898e-02,
		  -8.14819336e-03,-8.08715820e-03,-7.90405273e-03, 4.37316895e-02,
		   6.29577637e-02, 5.96008301e-02, 1.20208740e-01, 1.37756348e-01,
		   3.70178223e-02,-5.09643555e-03, 1.95922852e-02,-3.39965820e-02,
		  -7.99560547e-02,-4.36096191e-02,-2.75268555e-02,-4.27856445e-02,
		  -2.81982422e-02,-3.26538086e-03,-9.67407227e-03,-9.64355469e-03,
		   1.95312500e-02, 3.05480957e-02, 2.07519531e-02, 1.97143555e-02,
		   1.43127441e-02,-5.03540039e-03,-1.19934082e-02,-8.88061523e-03,
		  -1.74255371e-02,-3.06701660e-02,-2.86865234e-02,-2.31018066e-02,
		  -2.59399414e-02,-2.25524902e-02,-1.66320801e-02,-1.39160156e-02,
		  -9.27734375e-03,-2.99072266e-03,-3.05175781e-05, 3.35693359e-04,
		   1.73950195e-03, 1.55639648e-03, 1.70898438e-03, 5.79833984e-04,
		  -1.28173828e-03,-3.14331055e-03,-7.04956055e-03,-8.72802734e-03,
		  -8.60595703e-03,-8.91113281e-03,-9.52148438e-03,-7.84301758e-03,
		  -5.49316406e-03,-5.37109375e-03,-4.30297852e-03,-3.05175781e-03,
		  -3.57055664e-03,-4.48608398e-03,-3.23486328e-03,-1.98364258e-03,
		  -2.50244141e-03,-3.05175781e-03,-3.14331055e-03,-3.08227539e-03,
		  -4.97436523e-03,-6.59179688e-03,-6.43920898e-03,-6.19506836e-03,
		  -5.34057617e-03,-3.69262695e-03,-3.08227539e-03,-3.84521484e-03,
		  -3.75366211e-03,-3.08227539e-03,-3.44848633e-03,-3.93676758e-03,
		  -2.62451172e-03,-1.43432617e-03,-1.70898438e-03,-9.76562500e-04,
		  -7.32421875e-04,-1.89208984e-03,-3.32641602e-03,-3.32641602e-03,
		  -3.32641602e-03,-4.21142578e-03,-4.30297852e-03,-3.69262695e-03,
		  -2.62451172e-03,-2.22778320e-03,-2.47192383e-03,-2.99072266e-03,
		  -2.50244141e-03,-1.55639648e-03,-9.46044922e-04,-7.62939453e-04,
		  -8.85009766e-04,-4.57763672e-04,-6.40869141e-04,-1.55639648e-03
}, {
		2.56347656e-03,-3.84521484e-03, 5.43212891e-03,-9.18579102e-03,
		   1.79992676e-01, 4.68841553e-01,-3.13476562e-01,-6.68884277e-01,
		   2.35290527e-02, 2.72308350e-01, 2.34313965e-01, 1.34857178e-01,
		   5.67687988e-01, 7.64587402e-01, 1.45568848e-02,-3.81103516e-01,
		  -1.16668701e-01,-9.79919434e-02,-1.36322021e-01,-1.21307373e-01,
		  -2.86926270e-01,-2.65197754e-01,-2.22717285e-01,-7.73315430e-02,
		  -2.54211426e-02,-4.08935547e-02, 1.03210449e-01, 1.18957520e-01,
		   1.01715088e-01, 1.92382812e-01, 1.67510986e-01, 2.20336914e-02,
		  -3.51257324e-02,-8.41064453e-02,-6.82678223e-02,-8.62731934e-02,
		  -1.20513916e-01,-8.48388672e-02,-8.94470215e-02,-7.91625977e-02,
		  -5.20019531e-02,-4.35485840e-02,-1.26953125e-02, 4.32128906e-02,
		   5.09643555e-02, 4.74243164e-02, 4.88281250e-02, 4.91333008e-02,
		   4.49218750e-02, 2.79235840e-02, 2.18811035e-02, 4.02832031e-03,
		  -2.75268555e-02,-3.78723145e-02,-4.06494141e-02,-4.49218750e-02,
		  -4.06799316e-02,-3.75061035e-02,-3.14331055e-02,-2.64282227e-02,
		  -1.54113770e-02, 1.06811523e-02, 1.40075684e-02, 9.03320312e-03,
		   2.01721191e-02, 2.23999023e-02, 1.49841309e-02, 9.76562500e-03,
		   1.18103027e-02, 9.24682617e-03,-1.98364258e-03,-1.15356445e-02,
		  -1.11999512e-02,-1.49230957e-02,-1.75476074e-02,-1.20849609e-02,
		  -9.42993164e-03,-9.55200195e-03,-9.15527344e-03,-5.79833984e-03,
		  -3.78417969e-03,-4.88281250e-04, 6.16455078e-03, 9.24682617e-03,
		   6.95800781e-03, 2.22778320e-03, 1.19018555e-03, 2.74658203e-03,
		   6.10351562e-04,-8.23974609e-04,-3.81469727e-03,-9.58251953e-03,
		  -1.49230957e-02,-1.52282715e-02,-1.29394531e-02,-1.19628906e-02,
		  -8.57543945e-03,-6.40869141e-03,-6.22558594e-03,-5.21850586e-03,
		  -2.13623047e-03, 2.86865234e-03, 2.96020508e-03, 5.49316406e-04,
		  -9.15527344e-05,-3.66210938e-04, 1.00708008e-03, 1.86157227e-03,
		   6.10351562e-05,-3.57055664e-03,-6.01196289e-03,-8.27026367e-03,
		  -7.78198242e-03,-5.31005859e-03,-2.59399414e-03,-7.32421875e-04,
		  -6.71386719e-04, 7.62939453e-04, 3.20434570e-03, 5.58471680e-03,
		   6.22558594e-03, 5.00488281e-03, 3.44848633e-03, 1.95312500e-03,
		   1.15966797e-03, 1.34277344e-03, 8.85009766e-04, 6.40869141e-04
} };


arm_cfft_radix2_instance_f32 sine_instance;
arm_cfft_radix2_instance_f32 hrtf_instance;

float32_t sine_buffer[256];
float32_t fft_buf[2][128];
int16_t dataI2S[256];
float32_t fft_out[2][128];

//uint16_t sample_N;
//uint16_t circ_idx;

//total global memory
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

	sample_dt = F_OUT / FS;
	/*
	 * init FFT structs for input buffer, then hrtf
	 */
	/* initialization of structs, sine buffer */





	/* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_I2S3_Init();
  /* USER CODE BEGIN 2 */
  CS43_Init(hi2c1, MODE_I2S);
  CS43_SetVolume(50);
  CS43_Enable_RightLeft(CS43_RIGHT_LEFT);
  CS43_Start();

    get_sin(&sine_buffer[0]);
  	/* perform cfft structs */
  	arm_cfft_f32(&sine_instance, &sine_buffer[0], 0, 0);
  	arm_cfft_f32(&hrtf_instance, &coeffs[LEFT][0], 0, 0);
  	/* perform complex multiplies */

  	arm_cmplx_mult_cmplx_f32(&fft_buf[LEFT][0], &coeffs[LEFT][0], &fft_out[LEFT][0], 128);
  	arm_cfft_f32(&hrtf_instance, &coeffs[RIGHT][0], 0, 0);
  	arm_cmplx_mult_cmplx_f32(&fft_buf[RIGHT][0], &coeffs[RIGHT][0], &fft_out[RIGHT][0], 128);

  	arm_cfft_f32(&sine_instance, &fft_out[LEFT][0], 1, 0);
  	arm_cfft_f32(&sine_instance, &fft_out[RIGHT][0], 1, 0);

  	for(uint16_t i = 0; i < 128; i++)
  	{
  		dataI2S[2 * i] = 1600 * (fft_out[LEFT][i]);
  		dataI2S[2 * i + 1] = 1600 * (fft_out[RIGHT][i]);
  	}




  //Start DAC
  //fill_DMA_buffer(&dataI2S[0], &fir_l_output[0], &fir_r_output[0]);
  //HAL_I2S_Transmit_DMA(&hi2s3, (uint16_t *)dataI2S, 2 * FLOAT_BUF_SIZE);
	HAL_I2S_Transmit_DMA(&hi2s3, (uint16_t *)dataI2S, 256);
//  HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
  //Start TIM
//  HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage 
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 50;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2S3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S3_Init(void)
{

  /* USER CODE BEGIN I2S3_Init 0 */

  /* USER CODE END I2S3_Init 0 */

  /* USER CODE BEGIN I2S3_Init 1 */

  /* USER CODE END I2S3_Init 1 */
  hi2s3.Instance = SPI3;
  hi2s3.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s3.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s3.Init.DataFormat = I2S_DATAFORMAT_16B;
  hi2s3.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
  hi2s3.Init.AudioFreq = I2S_AUDIOFREQ_44K;
  hi2s3.Init.CPOL = I2S_CPOL_LOW;
  hi2s3.Init.ClockSource = I2S_CLOCK_PLL;
  hi2s3.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_DISABLE;
  if (HAL_I2S_Init(&hi2s3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S3_Init 2 */

  /* USER CODE END I2S3_Init 2 */

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15 
                          |GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PD12 PD13 PD14 PD15 
                           PD4 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15 
                          |GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void get_sin(float32_t *buf)
{
	for(uint16_t i = 0; i < FLOAT_BUF_SIZE; i++)
	{
		buf[i] = sinf(2 * i * PI * sample_dt);
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
